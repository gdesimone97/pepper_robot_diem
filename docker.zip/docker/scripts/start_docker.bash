#!/bin/bash

docker start -i pepper_ros_cnt
